﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using TTHLTV.BAL;
using System.Globalization;
using CrystalDecisions.Windows.Forms;
namespace TTHLTV.Report
{
    public partial class frmPrintView : DevExpress.XtraEditors.XtraForm
    {
        BO_DANG_KI_HOC boDkh = new BO_DANG_KI_HOC();
        BO_CAP_CHUNGCHI boCcc = new BO_CAP_CHUNGCHI();
        public int mChungChiId = -1;
        public int mLopId = -1;
        public int mIndex = -1;
        public string mSoHieuDoi = string.Empty;
        public int mCheckDoi = -1;
        public int StatustDoi = -1;
        private string mSoQT = string.Empty;
        public frmPrintView()
        {
            InitializeComponent();
        }
        private void frmInGiayChungNhan_Load(object sender, EventArgs e)
        {
            printReport();
           
        }
        private void printReport()
        {
            DataSet ds1 = new DataSet();
            if (mCheckDoi ==1)
            {
                #region Mat trong

                // In mat trong cua report
                if (mIndex == 1)
                {
                    //DataSet ds1 = new DataSet();
                    // Check cac chung chi do trung tam cap
                    if (mChungChiId == 31 || mChungChiId == 32 || mChungChiId == 33 || mChungChiId == 34 || mChungChiId == 14 || mChungChiId == 38 || mChungChiId == 39 || mChungChiId == 42)
                    {
                        Private_RpInGCN_MatTrong _rpt = new Private_RpInGCN_MatTrong();
                        ds1 = bidingDataSet_Mattrong();
                        _rpt.SetDataSource(ds1);
                        InGcnViewer.ReportSource = _rpt;
                        InGcnViewer.ToolPanelView = ToolPanelViewType.None;
                        InGcnViewer.RefreshReport();
                    }
                    else
                    {
                        RpInGCN_MatTrong rpt = new RpInGCN_MatTrong();
                        ds1 = bidingDataSet_Mattrong();
                        rpt.SetDataSource(ds1);
                        InGcnViewer.ReportSource = rpt;
                        InGcnViewer.ToolPanelView = ToolPanelViewType.None;
                        this.InGcnViewer.RefreshReport();
                    }
                    
                }
                #endregion
                #region Mat ngoai

                else if (mIndex == 2)
                {
                   // DataSet ds1 = new DataSet();
                    if (mChungChiId == 31 || mChungChiId == 32 || mChungChiId == 33 || mChungChiId == 34 || mChungChiId == 14 || mChungChiId == 38 || mChungChiId == 39 || mChungChiId == 42)
                    {
                        Private_RpInGCN_MatNgoai _rpt = new Private_RpInGCN_MatNgoai();
                        ds1 = bidingDataSet_Matngoai();
                        _rpt.SetDataSource(ds1);
                        InGcnViewer.ReportSource = _rpt;
                        InGcnViewer.ToolPanelView = ToolPanelViewType.None;
                        this.InGcnViewer.RefreshReport();
                    }
                    else
                    {
                        RpInGCN_MatNgoai rpt = new RpInGCN_MatNgoai();
                        ds1 = bidingDataSet_Matngoai();
                        rpt.SetDataSource(ds1);
                        InGcnViewer.ReportSource = rpt;
                        InGcnViewer.ToolPanelView = ToolPanelViewType.None;
                        this.InGcnViewer.RefreshReport();
 
                    }
                    
                }
                #endregion
            }
            else if (mCheckDoi>1)
            {
                #region Mat trong

                // In mat trong cua report
                if (mIndex == 1)
                {
                    //DataSet ds1 = new DataSet();
                    if (mChungChiId == 31 || mChungChiId == 32 || mChungChiId == 33 || mChungChiId == 34 || mChungChiId == 14 || mChungChiId == 38 || mChungChiId == 39 || mChungChiId == 42)
                    {
                        Private_RpInGCN_MatTrong _rpt = new Private_RpInGCN_MatTrong();
                        ds1 = bidingDataSet_Mattrong_Doi();
                        _rpt.SetDataSource(ds1);
                        InGcnViewer.ReportSource = _rpt;
                        InGcnViewer.ToolPanelView = ToolPanelViewType.None;
                        InGcnViewer.RefreshReport();

                    }
                    else
                    {

                        RpInGCN_MatTrong rpt = new RpInGCN_MatTrong();
                        //DataSet ds1 = new DataSet();
                        ds1 = bidingDataSet_Mattrong_Doi();
                        rpt.SetDataSource(ds1);
                        //rpt.SetParameterValue("SoQT", mSoQT);
                        InGcnViewer.ReportSource = rpt;
                        InGcnViewer.ToolPanelView = ToolPanelViewType.None;
                        this.InGcnViewer.RefreshReport();
                    }
                    
                }
                #endregion
                #region Mat ngoai

                else if (mIndex == 2)
                {
                    if (mChungChiId == 31 || mChungChiId == 32 || mChungChiId == 33 || mChungChiId == 34 || mChungChiId == 14 || mChungChiId == 38 || mChungChiId == 39 || mChungChiId == 42)
                    {

                        Private_RpInGCN_MatNgoai _rpt = new Private_RpInGCN_MatNgoai();
                        ds1 = bidingDataSet_Matngoai_Doi();
                        _rpt.SetDataSource(ds1);
                        InGcnViewer.ReportSource = _rpt;
                        InGcnViewer.ToolPanelView = ToolPanelViewType.None;
                        this.InGcnViewer.RefreshReport();

                    }
                    else
                    {

                        RpInGCN_MatNgoai rpt = new RpInGCN_MatNgoai();
                        //DataSet ds1 = new DataSet();
                        ds1 = bidingDataSet_Matngoai_Doi();
                        rpt.SetDataSource(ds1);
                        InGcnViewer.ReportSource = rpt;
                        InGcnViewer.ToolPanelView = ToolPanelViewType.None;
                        this.InGcnViewer.RefreshReport();
                    }
                }
                #endregion
            }
            
        }
        #region Chứng chỉ cấp mới
        private DataSet bidingDataSet_Matngoai()
        {
            DataTable tb = new DataTable();

            DsInGCN Ds = new DsInGCN();
            tb = boDkh.getDataInGCN(mLopId);
            for (int i = 0; i < tb.Rows.Count; i++)
            {
                int CHC_ID = Int32.Parse(tb.Rows[i]["CHC_ID"].ToString());
                DataRow row = Ds.TableInGcn_MatNgoai.NewRow();
                if (CHC_ID==31 ||CHC_ID==32 ||CHC_ID==33 ||CHC_ID==34 ||CHC_ID==14)
                {
                    row["HvSoCc"] = tb.Rows[i]["HvSoCc"].ToString();
                    Ds.TableInGcn_MatNgoai.Rows.Add(row);
                }
                else
                {
                // HUẤN LUYỆN NGHIỆP VỤ CƠ BẢN
                if (CHC_ID == 1)
                {
                    row["StaticNumber"] = "1.19,1.20,1.13,1.21";
                }
                //QUAN SÁT VÀ ĐỒ GIẢI RADAR  
                else if (CHC_ID == 12)
                {
                    row["StaticNumber"] = "1.07";
                }
                //THIẾT BỊ ĐỒ GIẢ RADAR TỰ ĐỘNG ( ARPA )
                else if (CHC_ID == 13)
                {
                    row["StaticNumber"] = "1.08";
                }
                //GMDSS-GOC
                else if (CHC_ID == 14)
                {
                    row["StaticNumber"] = "1.25";
                }
                //BÈ CỨU SINH, XUỐNG CỨU NẠN
                else if (CHC_ID == 18)
                {
                    row["StaticNumber"] = "1.23";
                }
                //QUẢN LÝ NHÂN LỰC BUỒNG MÁY
                else if (CHC_ID == 22)
                {
                    row["StaticNumber"] = " ";
                }
                //QUẢN LÝ NHÂN LỰC BUỒNG LÁI
                else if (CHC_ID == 21)
                {
                    row["StaticNumber"] = " ";
                }
                // Chờ xác nhận lại
                else if (CHC_ID == 0)
                {
                    row["StaticNumber"] = "001";
                }
                //CHĂM SÓC Y TẾ
                else if (CHC_ID == 17)
                {
                    row["StaticNumber"] = "1.15";
                }
                //KHAI THÁC TÀU HÓA CHẤT
                else if (CHC_ID == 5)
                {
                    row["StaticNumber"] = "1.04";
                }
                //KHAI THÁC TÀU DẦU
                else if (CHC_ID == 3)
                {
                    row["StaticNumber"] = "1.02";
                }
                //LÀM QUEN TÀU GAS
                else if (CHC_ID == 6)
                {
                    row["StaticNumber"] = "1.05";
                }
                //LÀM QUEN TÀU HÓA CHẤT
                else if (CHC_ID == 4)
                {
                    row["StaticNumber"] = "1.03";
                }
                //LÀM QUEN TÀU DẦU
                else if (CHC_ID == 2)
                {
                    row["StaticNumber"] = "1.01";
                }
                //KHAI THÁC TÀU GAS
                else if (CHC_ID == 7)
                {
                    row["StaticNumber"] = "1.06";
                }
                //HẢI ĐỒ ĐIỆN TỬ
                else if (CHC_ID == 24)
                {
                    row["StaticNumber"] = "1.27";
                }
                //CHỮA CHÁY NÂNG CAO
                else if (CHC_ID == 15)
                {
                    row["StaticNumber"] = "2.03";
                }
                //CỨU SINH NÂNG CAO
                else if (CHC_ID == 35)
                {
                    row["StaticNumber"] = "2.03";
                }
                //RỬA KHOANG DẦU 
                else if (CHC_ID == 38)
                {
                    row["StaticNumber"] = "2.03";
                }
                //SI QUAN DIEN
                else if (CHC_ID == 40)
                {
                    row["StaticNumber"] = "2.03";
                }
                //BỒI DƯỠNG NGHIỆP VỤ CÔNG ƯỚC HÀNG HẢI QUỐC TẾ
                else if (CHC_ID == 39)
                {
                    row["StaticNumber"] = "2.03";
                }
                    //HAI DO DIEN TU 2
                else if (CHC_ID == 41)
                {
                    row["StaticNumber"] = "2.03";
                }
                //    //TRÁI NGÀNH ĐIỆN
                //else if (CHC_ID == 41)
                //{
                //    row["StaticNumber"] = "2.03";
                //}
                DateTime fromDate = DateTime.Parse(tb.Rows[i]["LOP_Ngay_KG"].ToString());
                string sFromDate = fromDate.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
                row["FromDate"] = sFromDate.ToString().Substring(0, 2) + "/" + sFromDate.ToString().Substring(3, 2) + "/" + sFromDate.ToString().Substring(6, 4);
                DateTime endDate = DateTime.Parse(tb.Rows[i]["LOP_Ngay_KT"].ToString());
                string sEndDate = endDate.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
                row["ToDate"] = sEndDate.ToString().Substring(0, 2) + "/" + sEndDate.ToString().Substring(3, 2) + "/" + sEndDate.ToString().Substring(6, 4);
                row["At"] = " TT HUẤN LUYỆN THUYỀN VIÊN "; //\n SEMAN TRAINING CENTER \n ĐẠI HỌC GIAO THÔNG VẬN TẢI TP HCM \n HOCIMINH CITY UNIVERSITY OF TRANSPORT";
                row["At1"] = "SEMAN TRAINING CENTER";
                row["At2"] = "ĐẠI HỌC GIAO THÔNG VẬN TẢI TP HCM";
                row["At3"] = "HOCIMINH CITY UNIVERSITY OF TRANSPORT";
                row["ShortName"] = tb.Rows[i]["LOP_ShortName"].ToString();
                row["HvSoCc"] = tb.Rows[i]["HvSoCc"].ToString();
                DateTime sQdDate = DateTime.Parse(tb.Rows[i]["LOP_Ngay_QD"].ToString());
                string sSQdDate = sQdDate.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
                row["DateQd"] = sSQdDate.ToString().Substring(0, 2);
                row["MonthQd"] = sSQdDate.ToString().Substring(3, 2);
                row["YearQd"] = sSQdDate.ToString().Substring(6, 4); 
                Ds.TableInGcn_MatNgoai.Rows.Add(row);
            }
            }
           
            return Ds;
        }
        private DataSet bidingDataSet_Mattrong()
        {
            DataTable tb = new DataTable();

            DsInGCN Ds = new DsInGCN();
            tb = boDkh.getDataInGCN(mLopId);
            if (tb.Rows.Count>0)
            {
                for (int i = 0; i < tb.Rows.Count; i++)
                {
                    DataRow row = Ds.TableInGcn_MatTrong.NewRow();
                    row["TrungTam"] = "ĐẠI HỌC GIAO THÔNG VẬN TẢI TPHCM\n HOCHIMINH CITY UNIVERSITY OF TRANSPORT";
                    row["FullName"] = tb.Rows[i]["HvFirstName"].ToString() + " " + tb.Rows[i]["HvLastName"].ToString();
                    row["HvBirthDay"] = tb.Rows[i]["HvBirthDay"].ToString();
                    row["HOV_QuocTich"] = tb.Rows[i]["HOV_QuocTich"].ToString();
                    row["HvSoCc"] = tb.Rows[i]["HvSoCc"].ToString();
                    DateTime fromDate = DateTime.Parse(tb.Rows[i]["HvNgayCapSoCc"].ToString());
                    string sFromDate = fromDate.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
                    row["HvNgayCapSoCc"] = sFromDate.ToString().Substring(0, 2) + "/" + sFromDate.ToString().Substring(3, 2) + "/" + sFromDate.ToString().Substring(6, 4);

                    DateTime endDate = DateTime.Parse(tb.Rows[i]["HvNgayHetHan"].ToString());
                    string sEndDate = endDate.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
                    row["HvNgayHetHan"] = sEndDate.ToString().Substring(0, 2) + "/" + sEndDate.ToString().Substring(3, 2) + "/" + sEndDate.ToString().Substring(6, 4);
                    row["CHC_Name"] = tb.Rows[i]["CHC_Name"].ToString();
                    row["HvNoiSinh"] = tb.Rows[i]["HOV_NoiSinh"].ToString();
                    int CHC_ID = Int32.Parse(tb.Rows[i]["CHC_ID"].ToString());
                    /* Options cho nhieu mau chung chi */
                    // HUẤN LUYỆN NGHIỆP VỤ CƠ BẢN
                    if (CHC_ID == 1)
                    {
                        row["CHC_NameEnglish"] = " ";// "PERSIONAL SURVIVAL TECHNIQUES\n FIRE PREVENTION AND FIRE FIGHTING\n ELEMENTARY FIRST AID\n PERSONAL SAFETY AND SOCIAL RESPONSIBILITIES";
                        row["SoQT"] = " ";
                    }   
                    //QUAN SÁT VÀ ĐỒ GIẢI RADAR
                    else if (CHC_ID == 12)
                    {//// "THE OPERATIONAL USE OF AUTOMATIC\n RADAR PLOTTING AIDS - ARPA \n FOLLOWING THE RECOMMENDATION OF RESOLUTION\n No. 20 OF THE STCW 78/95 CONVENTION ";
                        row["CHC_NameEnglish"] = " RADAR OBSERVATION AND PLOTTING \n FOLLOWING THE RECOMENDATION OF RESOLUTION \n No. 18 OF THE STCW 78/95 CONVENTION";
                        row["SoQT"] = "A -II/I ";
                    }
                    //THIẾT BỊ ĐỒ GIẢ RADAR TỰ ĐỘNG ( ARPA )
                    else if (CHC_ID == 13)
                    {
                        row["CHC_NameEnglish"] = "RADAR OBSERVATION AND PLOTTING \n FOLLOWING THE RECOMENDATION OF RESOLUTION";
                        row["SoQT"] = "A -II/I ";
                    }
                    //BÈ CỨU SINH, XUỒNG CỨU NẠN
                    else if (CHC_ID == 18)
                    {
                        row["CHC_NameEnglish"] = "PROFICIENCY IN SURVIVAL CRAFT AND\n RESCUE BOAT AND FAST RESCUE BOAT";
                        row["SoQT"] = "VI/2 ";
                    }
                    //QUẢN LÝ NHÂN LỰC BUỒNG MÁY
                    else if (CHC_ID == 22)
                    {
                        row["CHC_NameEnglish"] = " \n ENGINE ROOM RESOURCE MANAGEMENT";
                        row["SoQT"] = "VIII ";
                    }
                    //QUẢN LÝ NHÂN LỰC BUỒNG LÁI
                    else if (CHC_ID == 21)
                    {
                        row["CHC_NameEnglish"] = "BRIDGE RESOURCE MANAGEMENT\n BRIDGE TEAM MANAGEMENT";
                        row["SoQT"] = "VIII ";
                    }
                    // Chờ xác nhận lại
                    else if (CHC_ID == 0)
                    {
                        row["CHC_NameEnglish"] = "BRIDGE RESOURCE MANAGEMENT\n BRIDGE TEAM MANAGEMENT";
                        row["SoQT"] = "VIII ";
                    }
                    //CHĂM SÓC Y TẾ
                    else if (CHC_ID == 17)
                    {
                        row["CHC_NameEnglish"] = " \n MEDICAL FIRST AID AND MEDICAL CARE";
                        row["SoQT"] = "VI/4 ";
                    }
                    //KHAI THÁC TÀU HÓA CHẤT
                    else if (CHC_ID == 5)
                    {
                        row["CHC_NameEnglish"] = "ADVANCE TRANING PROGRAMME\n ON CHEMICAL TANKER OPERATION";
                        row["SoQT"] = "                " + "V/1 ";
                    }
                    //KHAI THÁC TÀU DẦU
                    else if (CHC_ID == 3)
                    {
                        row["CHC_NameEnglish"] = "ADVANCE TRAINING PROGRAME\n ON OIL TANKER OPERATION";
                        row["SoQT"] = "                " + "V/1 ";
                    }
                    //LÀM QUEN TÀU GAS
                    else if (CHC_ID == 6)
                    {
                        row["CHC_NameEnglish"] = "\n LIQUEFIED GAS TANKER FAMILIARIZATION";
                        row["SoQT"] = "                " + "V/1 ";
                    }
                    //LÀM QUEN TÀU HÓA CHẤT
                    else if (CHC_ID == 4)
                    {
                        row["CHC_NameEnglish"] = "\n CHEMICAL TANKER FAMILIARIZATION";
                        row["SoQT"] = "                " + "V/1 ";
                    }
                    //LÀM QUEN TÀU DẦU
                    else if (CHC_ID == 2)
                    {
                        row["CHC_NameEnglish"] = "\n OIL TANKER FAMILIARIZATION";
                        row["SoQT"] = "                " + "V/1 ";
                    }
                    //KHAI THÁC TÀU GAS
                    else if (CHC_ID == 7)
                    {
                        row["CHC_NameEnglish"] = " ADVANCE TRANING PROGRAMME \n LIQUEFIED GAS TANKER FAMILIARIZATION";
                        row["SoQT"] = "                " + "V/1 ";
                    }
                    //HẢI ĐỒ ĐIỆN TỬ
                    else if (CHC_ID == 24)
                    {
                        row["CHC_NameEnglish"] = "OPERATIONAL USE OF ELECTRONIC\n CHART DISPLAY AND INFORMATION\n SYSTEMS ( ECDIS )";
                        row["SoQT"] = "A - II/1 ";
                    }
                    //CHỮA CHÁY NÂNG CAO
                    else if (CHC_ID == 15)
                    {
                        row["CHC_NameEnglish"] = "\nADVANCED FIRE FIGHTING";
                        row["SoQT"] = "VI/3 ";
                    }
                    //CỨU SINH NÂNG CAO
                    else if (CHC_ID == 35)
                    {
                        row["CHC_NameEnglish"] = "PROFICIENCY IN SURVIVAL CRAFT \n AND RESCUE BOAT AND FAST RESCUE BOAT";
                        row["SoQT"] = "VI/2 ";
                    }
                    //ĐỒ GIẢI TRÁNH VA ( ARPA )
                    else if (CHC_ID == 36)
                    {
                        row["CHC_NameEnglish"] = "THE OPERATIONAL USE OF AUTOMATIC RADAR PLOTTING \n AIDS - ARPA FOLLOWING THE RECOMMENDATION \n OF RESOLUTION \n No. 20 OF THE STCW 78/95 CONVENTION";
                        row["SoQT"] = "A-II/1";
                    }
                    //SHIPHANDLING
                    else if (CHC_ID == 37)
                    {
                        row["CHC_NameEnglish"] = "\n\nSHIPHANDLING";
                        row["SoQT"] = "A-II/2 ";
                    }
                    //TRÁI NGÀNH BOONG
                    else if (CHC_ID == 31)
                    {
                        row["CHC_NameEnglish"] = "BỔ TÚC TRÁI NGÀNH \n CHUYÊN NGÀNH ĐIỀU KHIỂN TÀU BIỂN";
                        row["LocationCenter"] = "";
                        row["Regulation"] = "";
                    }
                    //TRÁI NGÀNH MÁY
                    else if (CHC_ID == 32)
                    {
                        row["CHC_NameEnglish"] = "BỔ TÚC TRÁI NGÀNH \n CHUYÊN NGÀNH KHAI THÁC MÁY TÀU BIỂN";
                        row["LocationCenter"] = "";
                        row["Regulation"] = "";
                    }
                    //NÂNG CAO NGHIỆP VỤ BOONG
                    else if (CHC_ID == 33)
                    {
                        row["CHC_NameEnglish"] = "ĐÀO TẠO NÂNG CAO \n TRÌNH ĐỘ CHUYÊN MÔN HÀNG HẢI \n NGÀNH BOONG";
                        row["LocationCenter"] = "BỘ GIAO THÔNG VẬN TẢI ";
                        row["Regulation"] = "";
                    }
                    //NÂNG CAO NGHIỆP VỤ MÁY
                    else if (CHC_ID == 34)
                    {
                        row["CHC_NameEnglish"] = "ĐÀO TẠO NÂNG CAO \n TRÌNH ĐỘ CHUYÊN MÔN HÀNG HẢI \n NGÀNH MÁY";
                        row["LocationCenter"] = "BỘ GIAO THÔNG VẬN TẢI ";
                        row["Regulation"] = "";
                    }
                     //ĐIỆN BÁO VIÊN ( GOC )
                    else if (CHC_ID == 14)
                    {
                        row["CHC_NameEnglish"] = "GLOBAL MARITIME DISTRESS & SAFETY SYSTEM\nGENERAL OPERATOR'S CERTIFICATE\n(GMDSS - GOC)";//"GLOBAL MARITIME DISTRESE & STAEFY SYSTEM \n GENERAL OPERATORS CERTIFICATE\n ( GMDSS - GOC )";
                        row["LocationCenter"] = "Bộ luật STCW 95 - Điều khoản A-IV/2 ";
                        row["Regulation"] = "STCW 95 -  Regulation A-IV/2";
                    }
                    //RỬA KHOANG DẦU THÔ
                    else if (CHC_ID == 38)
                    {
                        row["CHC_NameEnglish"] = " CRUDE  OIL  WASHING";
                        row["LocationCenter"] = " ";
                        row["Regulation"] = "IMO  Regulation A. 446 (XI)";
                    }
                    //SI QUAN DIEN
                    else if (CHC_ID == 40)
                    {
                        row["CHC_NameEnglish"] = " THE ELECTRONIC CHART DISPLAY AND INFOMATIONS SYSTEM ( ECDIS) \n ACCORDING TO THE STCW-A.VIII/2 AND IMO MODEL COURSE 1.2.7 \n ( ON KELVIN HUGHES/NUCLEUS3 5000 ECDIS; \n FURUNIO/FEA-2107/2107-BB/2807; JRC/JAN-701/901 M)";
                        row["SoQT"] = "A-II/2 ";
                    }
                    //BỒI DƯỠNG NGHIỆP VỤ CÔNG ƯỚC HÀNG HẢI QUỐC TẾ
                    else if (CHC_ID == 39)
                    {
                        row["CHC_NameEnglish"] = " BỒI DƯỠNG NGHIỆP VỤ CÔNG ƯỚC HÀNG HẢI QUỐC TẾ \n UPDATE ON INTERNATIONAL MARITIME CONVENTIONS \n(SOLAS - MAPORL)";
                        row["LocationCenter"] = " ";
                        row["Regulation"] = "";
                    }
                    //HẢI ĐỒ ĐIỆN TỬ 2
                    else if (CHC_ID == 41)
                    {
                        row["CHC_NameEnglish"] = "THE ELECTRONIC CHART DISPLAY AND INFOMATION \n SYSTEM (ECDIS ) ACCORDING TO THE STCW-A.VIII/2\n IMO MODEL COURSE 1.27 \n(ON KELVIN HUGHES/NUCLEUS3 5000 ECDIS'\n FURUNO/FEA-2107/2107-BB/2807; JRC/JAN-701/901 M)";
                        row["SoQT"] = "";
                    }
                        //TRÁI NGÀNH ĐIỆN
                    else if (CHC_ID == 42)
                    {
                        row["CHC_NameEnglish"] = "BỔ TÚC TRÁI NGÀNH KỸ THUẬT ĐIỆN TÀU THỦY";
                        row["LocationCenter"] = "QUYẾT ĐINH 173/QĐ-BGTVT ";
                        row["Regulation"] = "";
                    }
                    Ds.TableInGcn_MatTrong.Rows.Add(row);
                }   
            }
            
            return Ds;
        }
        #endregion
        #region Chung chi doi
        private DataSet bidingDataSet_Matngoai_Doi()
        {
            DataTable tb = new DataTable();

            DsInGCN Ds = new DsInGCN();
            tb = boCcc.get_Print_CcDoi(mChungChiId, StatustDoi, mSoHieuDoi);
            for (int i = 0; i < tb.Rows.Count; i++)
            {
                 int CHC_ID = Int32.Parse(tb.Rows[i]["CHC_ID"].ToString());
                DataRow row = Ds.TableInGcn_MatNgoai.NewRow();
                if (CHC_ID == 31 || CHC_ID == 32 || CHC_ID == 33 || CHC_ID == 34 || CHC_ID == 14 || mChungChiId == 38 || mChungChiId == 39)
                {
                    row["HvSoCc"] = tb.Rows[i]["CCC_SoCc"].ToString();
                    //Ds.TableInGcn_MatNgoai.Rows.Add(row);
                }
                else
                
                // HUẤN NV LUYỆN CƠ BẢN
                if (CHC_ID == 1)
                {
                    row["StaticNumber"] = "1.19, 1.20, 1.13, 1.21";
                }
               
                //QUAN SÁT VÀ ĐỒ GIẢI RADAR
                else if (CHC_ID == 12)
                {
                    row["StaticNumber"] = "1.07";
                }
                //THIẾT BỊ ĐỒ GIẢ RADAR TỰ ĐỘNG ( ARPA )
                else if (CHC_ID == 13)
                {
                    row["StaticNumber"] = "1.08";
                }
                //GMDSS-GOC
                else if (CHC_ID == 14)
                {
                    row["StaticNumber"] = "1.25";
                }
                //BÈ CỨU SINH, XUỐNG CỨU NẠN
                else if (CHC_ID == 18)
                {
                    row["StaticNumber"] = "1.23";
                }
                //QUẢN LÝ NHÂN LỰC BUỒNG MÁY
                else if (CHC_ID == 22)
                {
                    row["StaticNumber"] = " ";
                }
                //QUẢN LÝ NHÂN LỰC BUỒNG LÁI
                else if (CHC_ID == 21)
                {
                    row["StaticNumber"] = " ";
                }
                // Chờ xác nhận lại
                else if (CHC_ID == 0)
                {
                    row["StaticNumber"] = "001";
                }
                //CHĂM SÓC Y TẾ
                else if (CHC_ID == 17)
                {
                    row["StaticNumber"] = "1.15";
                }
                //KHAI THÁC TÀU HÓA CHẤT
                else if (CHC_ID == 5)
                {
                    row["StaticNumber"] = "1.04";
                }
                //KHAI THÁC TÀU DẦU
                else if (CHC_ID == 3)
                {
                    row["StaticNumber"] = "1.02";
                }
                //LÀM QUEN TÀU GAS
                else if (CHC_ID == 6)
                {
                    row["StaticNumber"] = "1.05";
                }
                //LÀM QUEN TÀU HÓA CHẤT
                else if (CHC_ID == 4)
                {
                    row["StaticNumber"] = "1.03";
                }
                //KHAI THÁC TÀU GAS
                else if (CHC_ID == 7)
                {
                    row["StaticNumber"] = "1.06";
                }
                //LÀM QUEN TÀU DẦU
                else if (CHC_ID == 2)
                {
                    row["StaticNumber"] = "1.01";
                }
                //HẢI ĐỒ ĐIỆN TỬ
                else if (CHC_ID == 24)
                {
                    row["StaticNumber"] = "1.27";
                }
                //CHỮA CHÁY NÂNG CAO
                else if (CHC_ID == 15)
                {
                    row["StaticNumber"] = "2.03";
                }
                //RỬA KHOANG DẦU
                else if (CHC_ID == 38)
                {
                    row["StaticNumber"] = "2.03";
                }
                 //SI QUAN DIEN
                else if (CHC_ID == 39)
                {
                    row["StaticNumber"] = "2.03";
                }
                //HAI DO DIEN TU 2
                else if (CHC_ID == 41)
                {
                    row["StaticNumber"] = "2.03";
                }
                //CỨU SINH NÂNG CAO
                else if (CHC_ID == 35)
                {
                    row["StaticNumber"] = "2.03";
                }
                DateTime fromDate = DateTime.Parse(tb.Rows[i]["DOI_Ngay_KG"].ToString());
                string sFromDate = fromDate.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
                row["FromDate"] = sFromDate.ToString().Substring(0, 2) + "/" + sFromDate.ToString().Substring(3, 2) + "/" + sFromDate.ToString().Substring(6, 4);
                DateTime endDate = DateTime.Parse(tb.Rows[i]["DOI_Ngay_KT"].ToString());
                string sEndDate = endDate.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
                row["ToDate"] = sEndDate.ToString().Substring(0, 2) + "/" + sEndDate.ToString().Substring(3, 2) + "/" + sEndDate.ToString().Substring(6, 4);
                row["At"] = " TT HUẤN LUYỆN THUYỀN VIÊN \n SEMAN TRAINING CENTER \n ĐẠI HỌC GIAO THÔNG VẬN TẢI TP HCM \n HOCIMINH CITY UNIVERSITY OF TRANSPORT";
                row["ShortName"] = tb.Rows[i]["CCC_SoHieuDoi"].ToString();
                row["HvSoCc"] = tb.Rows[i]["CCC_SoCC"].ToString();
                DateTime sQdDate = DateTime.Parse(tb.Rows[i]["DOI_Ngay_QD"].ToString());
                string sSQdDate = sQdDate.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
                row["DateQd"] = sSQdDate.ToString().Substring(0, 2);
                row["MonthQd"] = sSQdDate.ToString().Substring(3, 2);
                row["YearQd"] = sSQdDate.ToString().Substring(6, 4);
                Ds.TableInGcn_MatNgoai.Rows.Add(row);
            }

            return Ds;
        }
        private DataSet bidingDataSet_Mattrong_Doi()
        {
            DataTable tb = new DataTable();

            DsInGCN Ds = new DsInGCN();
            tb = boCcc.get_Print_CcDoi(mChungChiId, StatustDoi, mSoHieuDoi);
            if (tb.Rows.Count>0)
            {
                for (int i = 0; i < tb.Rows.Count; i++)
                {
                    DataRow row = Ds.TableInGcn_MatTrong.NewRow();
                    int CHC_ID = Int32.Parse(tb.Rows[i]["CHC_ID"].ToString());
                    
                    row["TrungTam"] = "ĐẠI HỌC GIAO THÔNG VẬN TẢI TPHCM\n HOCHIMINH CITY UNIVERSITY OF TRANSPORT";
                    row["FullName"] = tb.Rows[i]["HOV_FirstName"].ToString() + " " + tb.Rows[i]["HOV_LastName"].ToString();
                    row["HvBirthDay"] = tb.Rows[i]["HOV_BirthDay"].ToString();
                    row["HOV_QuocTich"] = tb.Rows[i]["HOV_QuocTich"].ToString();
                    row["HvSoCc"] = tb.Rows[i]["CCC_SoCC"].ToString();
                    DateTime fromDate = DateTime.Parse(tb.Rows[i]["CCC_NgayCap"].ToString());
                    string sFromDate = fromDate.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
                    row["HvNgayCapSoCc"] = sFromDate.ToString().Substring(0, 2) + "/" + sFromDate.ToString().Substring(3, 2) + "/" + sFromDate.ToString().Substring(6, 4);

                    DateTime endDate = DateTime.Parse(tb.Rows[i]["CCC_NgayHetHan"].ToString());
                    string sEndDate = endDate.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
                    row["HvNgayHetHan"] = sEndDate.ToString().Substring(0, 2) + "/" + sEndDate.ToString().Substring(3, 2) + "/" + sEndDate.ToString().Substring(6, 4);
                    row["CHC_Name"] = tb.Rows[i]["CHC_Name"].ToString();
                    row["HvNoiSinh"] = tb.Rows[i]["HOV_NoiSinh"].ToString();
                   
                    /* Options cho nhieu mau chung chi */
                    // HUẤN LUYỆN NGHIỆP VỤ CƠ BẢN
                    if (CHC_ID == 1)
                    {
                        row["CHC_NameEnglish"] = " ";// "PERSIONAL SURVIVAL TECHNIQUES\n FIRE PREVENTION AND FIRE FIGHTING\n ELEMENTARY FIRST AID\n PERSONAL SAFETY AND SOCIAL RESPONSIBILITIES";
                        row["SoQT"] = " ";
                    }

                    //QUAN SÁT VÀ ĐỒ GIẢI RADAR
                    else if (CHC_ID == 12)
                    {
                        //row["CHC_NameEnglish"] = "THE OPERATIONAL USE OF AUTOMATIC\n RADAR PLOTTING AIDS - ARPA \n FOLLOWING THE RECOMMENDATION OF RESOLUTION\n No. 18 OF THE STCW 78/95 CONVENTION ";
                        row["CHC_NameEnglish"] = "RADAR OBSERVATION AND PLOTTING \n FOLLOWING THE RECOMENDATION OF RESOLUTION \n No. 18 OF THE STCW 78/95 CONVENTION";
                        row["SoQT"] = "A -II/I ";
                    }
                    //THIẾT BỊ ĐỒ GIẢ RADAR TỰ ĐỘNG ( ARPA )
                    else if (CHC_ID == 13)
                    {
                        row["CHC_NameEnglish"] = "THE OPERATIONAL USE OF AUTOMATIC\n RADAR PLOTTING AIDS - ARPA \n FOLLOWING THE RECOMMENDATION OF RESOLUTION\n No. 20 OF THE STCW 78/95 CONVENTION ";//"RADAR OBSERVATION AND PLOTTING RADAR\n PLOTTING FOLLOWING THE RECOMENDATION OF RESOLUTION";
                        row["SoQT"] = "A -II/I ";
                    }
                    else if (CHC_ID == 18)
                    {
                        row["CHC_NameEnglish"] = "PROFICIENCY IN SURVIVAL CRAFT AND\n RESCUE BOAT AND FAST RESCUE BOAT";
                        row["SoQT"] = "VI/2 ";
                    }
                    //QUẢN LÝ NHÂN LỰC BUỒNG MÁY
                    else if (CHC_ID == 22)
                    {
                        row["CHC_NameEnglish"] = "\n ENGINE ROOM RESOURCE MANAGEMENT";
                        row["SoQT"] = "VIII ";
                    }
                    //QUẢN LÝ NHÂN LỰC BUỒNG LÁI
                    else if (CHC_ID == 21)
                    {
                        row["CHC_NameEnglish"] = "BRIDGE RESOURCE MANAGEMENT\n BRIDGE TEAM MANAGEMENT";
                        row["SoQT"] = "VIII ";
                    }
                    // Chờ xác nhận lại
                    else if (CHC_ID == 0)
                    {
                        row["CHC_NameEnglish"] = "BRIDGE RESOURCE MANAGEMENT\n BRIDGE TEAM MANAGEMENT";
                        row["SoQT"] = "VIII ";
                    }
                    //CHĂM SÓC Y TẾ
                    else if (CHC_ID == 17)
                    {
                        row["CHC_NameEnglish"] = "\n MEDICAL FIRST AID AND MEDICAL CARE";
                        row["SoQT"] = "VI/4 ";
                    }
                    //KHAI THÁC TÀU HÓA CHẤT
                    else if (CHC_ID == 5)
                    {
                        row["CHC_NameEnglish"] = "ADVANCE TRANING PROGRAMME\n ON CHEMICAL TANKER OPERATION";
                        row["SoQT"] = "                " + "V/1 ";
                    }
                    //KHAI THÁC TÀU DẦU
                    else if (CHC_ID == 3)
                    {
                        row["CHC_NameEnglish"] = "ADVANCE TRAINING PROGRAME\n ON OIL TANKER OPERATION";
                        row["SoQT"] = "                " + "V/1 ";
                    }
                    //LÀM QUEN TÀU GAS
                    else if (CHC_ID == 6)
                    {
                        row["CHC_NameEnglish"] = "\n LIQUEFIED GAS TANKER FAMILIARIZATION";
                        row["SoQT"] = "                " + "V/1 ";
                    }
                    //LÀM QUEN TÀU HÓA CHẤT
                    else if (CHC_ID == 4)
                    {
                        row["CHC_NameEnglish"] = "\n CHEMICAL TANKER FAMILIARIZATION";
                        row["SoQT"] = "                " + "V/1 ";
                    }
                    //LÀM QUEN TÀU DẦU
                    else if (CHC_ID == 2)
                    {
                        row["CHC_NameEnglish"] = "\n OIL TANKER FAMILIARIZATION";
                        row["SoQT"] = "                " + "V/1 ";
                    }
                    //KHAI THÁC TÀU GAS
                    else if (CHC_ID == 7)
                    {
                        row["CHC_NameEnglish"] = "\n ADVANCE TRANING PROGRAMME \n LIQUEFIED GAS TANKER OPERATION";
                        row["SoQT"] = "                " + "V/1 ";
                    }
                    //HẢI ĐỒ ĐIỆN TỬ
                    else if (CHC_ID == 24)
                    {
                        row["CHC_NameEnglish"] = "OPERATIONAL USE OF ELECTRONIC\n CHART DISPLAY AND INFORMATION\n SYSTEMS ( ECDIS )";
                        row["SoQT"] = "A - II/1 ";
                    }
                    //CHỮA CHÁY NÂNG CAO
                    else if (CHC_ID == 15)
                    {
                        row["CHC_NameEnglish"] = "\n ADVANCED FIRE FIGHTING";
                        row["SoQT"] = "VI/3 ";
                    }
                    //CỨU SINH NÂNG CAO
                    else if (CHC_ID == 35)
                    {
                        row["CHC_NameEnglish"] = "PROFICIENCY IN SURVIVAL CRAFT \n AND RESCUE BOAT AND FAST RESCUE BOAT";
                        row["SoQT"] = "VI/2 ";
                    }
                    //ĐỒ GIẢI TRÁNH VA
                    else if (CHC_ID == 36)
                    {
                        row["CHC_NameEnglish"] = "THE OPERATIONAL USE OF AUTOMATIC RADAR PLOTTING \n AIDS - ARPA FOLLOWING THE RECOMMENDATION \n OF RESOLUTION \n No. 20 OF THE STCW 78/95 CONVENTION";
                        row["SoQT"] = "A - II/1";
                    }
                    //SHIPHANDLING
                    else if (CHC_ID == 37)
                    {
                        row["CHC_NameEnglish"] = "\n\nSHIPHANDLING";
                        row["SoQT"] = "A-II/2 ";
                    }
                    //TRÁI NGÀNH BOONG
                    else if (CHC_ID == 31)
                    {
                        row["CHC_NameEnglish"] = "BỔ TÚC TRÁI NGÀNH \n CHUYÊN NGÀNH ĐIỀU KHIỂN TÀU BIỂN";
                        row["LocationCenter"] = "";
                        row["Regulation"] = "";
                    }
                    //TRÁI NGÀNH MÁY
                    else if (CHC_ID == 32)
                    {
                        row["CHC_NameEnglish"] = "BỔ TÚC TRÁI NGÀNH \n CHUYÊN NGÀNH KHAI THÁC MÁY TÀU BIỂN";
                        row["LocationCenter"] = "";
                        row["Regulation"] = "";
                    }
                    //NÂNG CAO NGHIỆP VỤ BOONG
                    else if (CHC_ID == 33)
                    {
                        row["CHC_NameEnglish"] = "ĐÀO TẠO NÂNG CAO \n TRÌNH ĐỘ CHUYÊN MÔN HÀNG HẢI \n NGÀNH BOONG";
                        row["LocationCenter"] = "BỘ GIAO THÔNG VẬN TẢI ";
                        row["Regulation"] = "";
                    }
                    //NÂNG CAO NGHIỆP VỤ MÁY
                    else if (CHC_ID == 34)
                    {
                        row["CHC_NameEnglish"] = "ĐÀO TẠO NÂNG CAO \n TRÌNH ĐỘ CHUYÊN MÔN HÀNG HẢI \n NGÀNH MÁY";
                        row["LocationCenter"] = "BỘ GIAO THÔNG VẬN TẢI ";
                        row["Regulation"] = "";
                    }

                     //ĐIỆN BÁO VIÊN ( GOC )
                    else if (CHC_ID == 14)
                    {
                        row["CHC_NameEnglish"] = "GLOBAL MARITIME DISTRESE & STAEFY SYSTEM \n GENERAL OPERATORS CERTIFICATE\n ( GMDSS - GOC )";
                        row["LocationCenter"] = "Bộ luật STCW 95 - Điều khoản A-IV/2 ";
                        row["Regulation"] = "STCW 95 -  Regulation A-IV/2";
                    }
                    //RỬA KHOANG DẦU
                    else if (CHC_ID == 38)
                    {
                        row["CHC_NameEnglish"] = "Vô tuyến điện Hàng hải \n GMDSS";
                        row["LocationCenter"] = "Bộ luật STCW 95 - Điều khoản A-IV/2 ";
                        row["Regulation"] = "STCW 95 -  Regulation A-IV/2";
                    }
                    //SI QUAN DIEN
                    else if (CHC_ID == 39)
                    {
                        row["CHC_NameEnglish"] = " THE ELECTRONIC CHART DISPLAY AND INFOMATIONS SYSTEM ( ECDIS) \n ACCORDING TO THE STCW-A.VIII/2 AND IMO MODEL COURSE 1.2.7 \n ( ON KELVIN HUGHES/NUCLEUS3 5000 ECDIS; \n FURUNIO/FEA-2107/2107-BB/2807; JRC/JAN-701/901 M)";
                        row["SoQT"] = "A-II/2 ";
                    }
                    //HẢI ĐỒ ĐIỆN TỬ 2
                    else if (CHC_ID == 41)
                    {
                        row["CHC_NameEnglish"] = "THE ELECTRONIC CHART DISPLAY AND INFOMATION \n SYSTEM (ECDIS ) ACCORDING TO THE STCW-A.VIII/2\n IMO MODEL COURSE 1.27 \n(ON KELVIN HUGHES/NUCLEUS3 5000 ECDIS'\n FURUNO/FEA-2107/2107-BB/2807; JRC/JAN-701/901 M)";
                        row["SoQT"] = "";
                    }
                    //TRÁI NGÀNH ĐIỆN
                    else if (CHC_ID == 42)
                    {
                        row["CHC_NameEnglish"] = "BỔ TÚC TRÁI NGÀNH KỸ THUẬT ĐIỆN TÀU THỦY";
                        row["LocationCenter"] = "QUYẾT ĐINH 173/QĐ-BGTVT";
                        row["Regulation"] = "";
                    }
                    Ds.TableInGcn_MatTrong.Rows.Add(row);
                }  
            }
            
            return Ds;
        }
        #endregion
    }
}