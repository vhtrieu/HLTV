﻿namespace TTHLTV.Report {
    
    
    public partial class DsInGCN {
        partial class TableInGcn_MatTrongDataTable
        {
        }
    
    }
}
