﻿(function () {
    angular.module('common',
        [])
})();